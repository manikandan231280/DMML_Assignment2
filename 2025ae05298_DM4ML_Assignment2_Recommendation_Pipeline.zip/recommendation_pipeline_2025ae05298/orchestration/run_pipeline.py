from pathlib import Path
import sys, json, traceback
import pandas as pd

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.ingestion.ingest import ingest
from src.validation.validate import validate
from src.preparation.prepare import prepare
from src.features.build_features import build_features
from src.training.train import train_models
from src.evaluation.evaluate import evaluate

def log(lines, message):
    print(message, flush=True)
    lines.append(message)

def main():
    (ROOT/"reports").mkdir(exist_ok=True)
    lines=[]
    try:
        log(lines, "STAGE 1/7 — DATA INGESTION")
        counts=ingest(ROOT)
        log(lines, f"PASS: generated users={counts['users']}, items={counts['items']}, interactions={counts['interactions']}")
        log(lines, "STAGE 2/7 — DATA VALIDATION")
        valid, users, items, checks, quarantined=validate(ROOT)
        log(lines, f"PASS: {len(valid)} valid rows; {quarantined} rows quarantined; {len(checks)} automated checks recorded")
        log(lines, "STAGE 3/7 — DATA PREPARATION")
        train,test,users,items=prepare(ROOT,valid,users,items)
        log(lines, f"PASS: chronological split train={len(train)} test={len(test)}")
        log(lines, "STAGE 4/7 — FEATURE MANAGEMENT")
        uf, itf, inf=build_features(ROOT,train,users,items)
        log(lines, f"PASS: user_features={len(uf)} item_features={len(itf)} interaction_features={len(inf)}")
        log(lines, "STAGE 5/7 — MODEL TRAINING")
        models,params=train_models(ROOT,train,items)
        log(lines, "PASS: trained popularity baseline and personalized user-user collaborative filtering")
        log(lines, "STAGE 6/7 — MODEL EVALUATION")
        results=evaluate(ROOT,models,train,test,items)
        log(lines, "PASS: Precision@5, Recall@5, NDCG@5, Coverage and Diversity calculated")
        log(lines, "STAGE 7/7 — ORCHESTRATION / EXPERIMENT TRACKING")
        experiment={"experiment":"recommendation_pipeline","roll_number":"2025ae05298","seed":42,"model_parameters":params,"metrics":results.to_dict(orient="records")}
        (ROOT/"reports/experiment_tracking.json").write_text(json.dumps(experiment,indent=2))
        log(lines, "PASS: dependency-ordered workflow completed; experiment metadata and artifacts persisted")
        log(lines, "PIPELINE STATUS: SUCCESS")
    except Exception as exc:
        log(lines, f"PIPELINE STATUS: FAILED — {exc}")
        traceback.print_exc()
        raise
    finally:
        (ROOT/"reports/pipeline_execution.log").write_text("\\n".join(lines)+"\\n")

if __name__=="__main__":
    main()
