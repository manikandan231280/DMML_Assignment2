from pathlib import Path
import pandas as pd

def validate(base: Path):
    raw = base / "data/raw"
    users = pd.read_csv(raw/"users.csv")
    items = pd.read_csv(raw/"items.csv")
    x = pd.read_csv(raw/"interactions.csv")
    checks = {}
    checks["missing_required"] = x[["interaction_id","user_id","item_id","rating","timestamp"]].isna().any(axis=1)
    checks["duplicate_id"] = x["interaction_id"].duplicated(keep="first")
    rating = pd.to_numeric(x["rating"], errors="coerce")
    checks["invalid_rating_or_type"] = rating.isna() | ~rating.between(1,5)
    ts = pd.to_datetime(x["timestamp"], errors="coerce", utc=True)
    checks["invalid_timestamp"] = ts.isna()
    checks["unknown_user"] = ~x["user_id"].isin(users["user_id"])
    checks["unknown_item"] = ~x["item_id"].isin(items["item_id"])
    bad = pd.Series(False, index=x.index)
    report = []
    for name, mask in checks.items():
        mask = mask.fillna(True)
        bad |= mask
        report.append({"check": name, "failed_rows": int(mask.sum()), "status": "PASS" if mask.sum()==0 else "QUARANTINED"})
    errors = x.loc[bad].copy()
    valid = x.loc[~bad].copy()
    (base/"data/errors").mkdir(parents=True, exist_ok=True)
    errors.to_csv(base/"data/errors/invalid_interactions.csv", index=False)
    pd.DataFrame(report).to_csv(base/"reports/validation_report.csv", index=False)
    valid["rating"] = pd.to_numeric(valid["rating"]).astype(int)
    valid["timestamp"] = pd.to_datetime(valid["timestamp"], utc=True)
    return valid, users, items, report, len(errors)
