from pathlib import Path
import json
import numpy as np
import pandas as pd

def _metrics(model, train, test, items, k=5):
    seen = train.groupby("user_id")["item_id"].apply(set).to_dict()
    truth = test.groupby("user_id")["item_id"].apply(set).to_dict()
    category = items.set_index("item_id")["category"].to_dict()
    precisions, recalls, ndcgs, diversities = [], [], [], []
    recommended_catalog = set()
    for user, relevant in truth.items():
        recs = model.recommend(user, seen.get(user,set()), k)
        recommended_catalog.update(recs)
        hits = [1 if item in relevant else 0 for item in recs]
        precisions.append(sum(hits)/k)
        recalls.append(sum(hits)/len(relevant) if relevant else 0)
        dcg = sum(hit/np.log2(rank+2) for rank,hit in enumerate(hits))
        ideal = sum(1/np.log2(rank+2) for rank in range(min(len(relevant),k)))
        ndcgs.append(dcg/ideal if ideal else 0)
        cats = [category.get(i,"Unknown") for i in recs]
        diversities.append(len(set(cats))/len(cats) if cats else 0)
    return {
      f"Precision@{k}": float(np.mean(precisions)),
      f"Recall@{k}": float(np.mean(recalls)),
      f"NDCG@{k}": float(np.mean(ndcgs)),
      "Coverage": float(len(recommended_catalog)/len(items)),
      "Diversity": float(np.mean(diversities))
    }

def evaluate(base: Path, models, train, test, items):
    rows=[]
    for name, model in models.items():
        row={"model":name, **_metrics(model,train,test,items,k=5)}
        rows.append(row)
    result=pd.DataFrame(rows)
    result.to_csv(base/"reports/model_evaluation.csv", index=False)
    (base/"reports/model_evaluation.json").write_text(result.to_json(orient="records", indent=2))
    return result
