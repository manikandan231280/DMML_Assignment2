from pathlib import Path
import pandas as pd

def build_features(base: Path, train, users, items):
    user = train.groupby("user_id").agg(
        user_activity_count=("interaction_id","count"),
        user_average_rating=("rating","mean"),
        last_interaction=("timestamp","max")
    ).reset_index()
    user_pref = (train.merge(items[["item_id","category"]], on="item_id")
                 .groupby(["user_id","category"]).size().reset_index(name="n")
                 .sort_values(["user_id","n","category"], ascending=[True,False,True])
                 .drop_duplicates("user_id")[["user_id","category"]]
                 .rename(columns={"category":"preferred_category"}))
    user = user.merge(user_pref, on="user_id", how="left")
    item = train.groupby("item_id").agg(
        item_popularity=("interaction_id","count"),
        item_average_rating=("rating","mean")
    ).reset_index()
    item = items.merge(item, on="item_id", how="left")
    item[["item_popularity","item_average_rating"]] = item[["item_popularity","item_average_rating"]].fillna(0)
    max_ts = train["timestamp"].max()
    interaction = train[["interaction_id","user_id","item_id","rating","timestamp"]].copy()
    interaction["days_since_interaction"] = (max_ts - interaction["timestamp"]).dt.total_seconds()/86400
    out = base/"data/features"
    out.mkdir(parents=True, exist_ok=True)
    user.to_csv(out/"user_features.csv", index=False)
    item.to_csv(out/"item_features.csv", index=False)
    interaction.to_csv(out/"interaction_features.csv", index=False)
    catalog = [
      ["user_activity_count","User","Count of training interactions","Training and user profile"],
      ["user_average_rating","User","Mean rating supplied by user","Training and ranking"],
      ["preferred_category","User","Most-interacted item category","Personalization"],
      ["item_popularity","Item","Number of training interactions","Popularity baseline"],
      ["item_average_rating","Item","Mean training rating for item","Ranking feature"],
      ["days_since_interaction","Interaction","Age in days relative to latest training event","Recency analysis"],
    ]
    pd.DataFrame(catalog, columns=["feature","entity","definition","usage"]).to_csv(base/"reports/feature_catalog.csv", index=False)
    return user, item, interaction
