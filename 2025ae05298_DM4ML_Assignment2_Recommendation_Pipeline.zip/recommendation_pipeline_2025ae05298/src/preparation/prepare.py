from pathlib import Path
import pandas as pd

def prepare(base: Path, interactions, users, items):
    # Keep only one record per interaction identifier; validation already quarantines duplicate IDs.
    x = interactions.drop_duplicates(subset=["interaction_id"]).copy()
    users = users.copy()
    items = items.copy()
    users["age"] = users["age"].fillna(users["age"].median())
    users["region"] = users["region"].fillna("Unknown")
    items["category"] = items["category"].fillna("Unknown")
    items["price"] = items["price"].fillna(items["price"].median())
    x = x.merge(users[["user_id"]], on="user_id", how="inner").merge(items[["item_id"]], on="item_id", how="inner")
    x = x.sort_values("timestamp").reset_index(drop=True)
    split_at = int(len(x) * 0.8)
    train, test = x.iloc[:split_at].copy(), x.iloc[split_at:].copy()
    out = base/"data/processed"
    out.mkdir(parents=True, exist_ok=True)
    x.to_csv(out/"clean_interactions.csv", index=False)
    train.to_csv(out/"train_interactions.csv", index=False)
    test.to_csv(out/"test_interactions.csv", index=False)
    users.to_csv(out/"users_clean.csv", index=False)
    items.to_csv(out/"items_clean.csv", index=False)
    return train, test, users, items
