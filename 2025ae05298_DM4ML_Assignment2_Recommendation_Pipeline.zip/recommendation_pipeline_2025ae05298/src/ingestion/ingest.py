from pathlib import Path
import numpy as np
import pandas as pd

def ingest(base: Path, seed: int = 42):
    rng = np.random.default_rng(seed)
    n_users, n_items, n_interactions = 180, 100, 7200
    categories = ["Books", "Electronics", "Home", "Sports", "Music"]
    users = pd.DataFrame({
        "user_id": [f"U{i:04d}" for i in range(n_users)],
        "age": rng.integers(18, 66, n_users),
        "region": rng.choice(["North", "South", "East", "West"], n_users),
    })
    items = pd.DataFrame({
        "item_id": [f"I{i:04d}" for i in range(n_items)],
        "category": rng.choice(categories, n_items),
        "price": np.round(rng.uniform(5, 250, n_items), 2),
    })
    # Latent user-category preferences create learnable structure.
    prefs = rng.random((n_users, len(categories)))
    prefs = prefs / prefs.sum(axis=1, keepdims=True)
    chosen_users = rng.integers(0, n_users, n_interactions)
    chosen_items = []
    for u in chosen_users:
        cat_idx = rng.choice(len(categories), p=prefs[u])
        candidates = np.where(items["category"].to_numpy() == categories[cat_idx])[0]
        chosen_items.append(int(rng.choice(candidates)))
    start = pd.Timestamp("2025-01-01", tz="UTC")
    offsets = rng.integers(0, 300*24*60, n_interactions)
    timestamps = start + pd.to_timedelta(offsets, unit="m")
    ratings = np.clip(np.rint(rng.normal(3.8, 0.9, n_interactions)), 1, 5).astype(int)
    interactions = pd.DataFrame({
        "interaction_id": [f"X{i:06d}" for i in range(n_interactions)],
        "user_id": users.loc[chosen_users, "user_id"].to_numpy(),
        "item_id": items.loc[chosen_items, "item_id"].to_numpy(),
        "rating": ratings,
        "event_type": rng.choice(["view", "click", "purchase"], n_interactions, p=[.45,.35,.20]),
        "timestamp": timestamps.astype(str),
    })
    # Deliberate defects for validation demonstration.
    interactions.loc[0, "rating"] = 8
    interactions.loc[1, "user_id"] = "U9999"
    interactions.loc[2, "timestamp"] = "not-a-timestamp"
    interactions.loc[3, "rating"] = np.nan
    interactions = pd.concat([interactions, interactions.iloc[[4]]], ignore_index=True)
    raw = base / "data/raw"
    raw.mkdir(parents=True, exist_ok=True)
    users.to_csv(raw/"users.csv", index=False)
    items.to_csv(raw/"items.csv", index=False)
    interactions.to_csv(raw/"interactions.csv", index=False)
    return {"users": len(users), "items": len(items), "interactions": len(interactions)}
