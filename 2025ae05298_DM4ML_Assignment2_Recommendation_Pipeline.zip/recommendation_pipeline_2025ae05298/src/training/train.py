from pathlib import Path
import json, joblib
import numpy as np
import pandas as pd
from sklearn.metrics.pairwise import cosine_similarity

class PopularityRecommender:
    def fit(self, train, items):
        self.catalog = items["item_id"].tolist()
        counts = train.groupby("item_id").size().to_dict()
        self.ranking = sorted(self.catalog, key=lambda i: (-counts.get(i,0), i))
        return self
    def recommend(self, user_id, seen, k=5):
        return [i for i in self.ranking if i not in seen][:k]

class UserUserCF:
    def fit(self, train, items):
        self.catalog = items["item_id"].tolist()
        self.matrix = train.pivot_table(index="user_id", columns="item_id", values="rating", aggfunc="mean").reindex(columns=self.catalog).fillna(0)
        self.sim = cosine_similarity(self.matrix.to_numpy())
        self.user_index = {u:i for i,u in enumerate(self.matrix.index)}
        self.item_index = {it:i for i,it in enumerate(self.catalog)}
        self.global_pop = train.groupby("item_id").size().to_dict()
        return self
    def recommend(self, user_id, seen, k=5):
        if user_id not in self.user_index:
            return sorted([i for i in self.catalog if i not in seen], key=lambda x:(-self.global_pop.get(x,0),x))[:k]
        idx = self.user_index[user_id]
        sims = self.sim[idx].copy()
        sims[idx] = 0
        neighbor_ids = np.argsort(sims)[::-1][:30]
        scores = np.zeros(len(self.catalog))
        for n in neighbor_ids:
            if sims[n] > 0:
                scores += sims[n] * self.matrix.iloc[n].to_numpy()
        own = self.matrix.iloc[idx].to_numpy()
        candidates = [(it, scores[j]) for j,it in enumerate(self.catalog) if it not in seen]
        candidates.sort(key=lambda z:(-z[1], -self.global_pop.get(z[0],0), z[0]))
        return [it for it,_ in candidates[:k]]

def train_models(base: Path, train, items):
    pop = PopularityRecommender().fit(train, items)
    cf = UserUserCF().fit(train, items)
    models = base/"models"
    models.mkdir(exist_ok=True)
    joblib.dump(pop, models/"popularity.joblib")
    joblib.dump(cf, models/"user_user_cf.joblib")
    params = {"popularity":{"type":"count ranking"}, "user_user_cf":{"similarity":"cosine","neighbors":30,"rating_signal":"explicit ratings"}}
    (models/"model_parameters.json").write_text(json.dumps(params, indent=2))
    return {"popularity":pop, "user_user_cf":cf}, params
