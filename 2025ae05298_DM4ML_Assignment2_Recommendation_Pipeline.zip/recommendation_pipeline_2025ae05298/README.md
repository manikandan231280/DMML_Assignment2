# End-to-End Recommendation Data Management Pipeline
**Roll number:** `2025ae05298`  
**Assignment:** Data Management for Machine Learning – Assignment 2  
**GitHub repository:** https://github.com/manikandan231280/mani_repo

## Overview
A reproducible, modular recommendation pipeline using documented synthetic e-commerce data. It implements ingestion, automated validation/quarantine, cleaning and chronological splitting, reusable feature tables, two recommenders, ranking evaluation, local experiment tracking, and a dependency-ordered Python workflow.

## Quick start
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python -m orchestration.run_pipeline
```
The run writes raw/processed/features/error datasets, model artifacts, metrics, experiment metadata, logs and execution evidence under the project directory.

## Pipeline stages
1. **Ingestion:** creates reproducible synthetic users, items and timestamped interactions; saves CSV files in `data/raw/`.
2. **Validation:** checks nulls, duplicate interaction IDs, types/ranges, timestamps and user/item referential integrity. Invalid rows are quarantined in `data/errors/`.
3. **Preparation:** removes duplicate records, filters invalid records, imputes missing user/item descriptive values, sorts by time and creates a chronological 80/20 interaction split.
4. **Feature management:** creates user activity/average-rating/preferred-category features, item popularity/average-rating features, and interaction recency features. Feature definitions are in `reports/feature_catalog.csv`.
5. **Training:** popularity baseline and personalized user-user collaborative filtering (cosine similarity).
6. **Evaluation:** Precision@5, Recall@5, NDCG@5, catalog coverage and intra-list category diversity. Metrics are written to CSV and JSON. This is an implicit top-N evaluation derived from held-out positive interactions.
7. **Orchestration:** `orchestration/run_pipeline.py` runs dependent tasks in order and stops on failure. It is a clearly structured Python workflow, one of the assignment's permitted orchestration choices.

## Data and reproducibility
The data is synthetic, generated with a fixed random seed (`42`) and is not sourced from real users. The generator intentionally inserts a small number of data-quality defects to demonstrate quarantine. The test set is later in time than the training set to avoid random temporal leakage.

## Outputs
- `data/raw/`: generated source CSVs
- `data/processed/`: validated, cleaned and train/test interactions
- `data/features/`: reusable user, item and interaction features
- `data/errors/`: quarantined interaction records
- `models/`: serialized model parameters
- `reports/`: validation report, feature catalog, metrics, experiment log and run log
- `reports/screenshots/`: terminal-style execution evidence captured from actual stage log output

## Notes and limitations
The personalized model is a lightweight user-user collaborative-filtering implementation for a teaching assignment. It may be less effective for cold-start users/items and sparse data. The synthetic data is intentionally small; production deployment would need access controls, schema/version management, monitoring, online serving and a managed feature store. The local JSON experiment tracker is used as the permitted "another experiment-tracking tool"; MLflow can be added for a production-grade tracking server.
